# wikidichConverter

This is a program to crawl book's content from wikidich.net provided the link of the book, and convert all chapters into a pdf file.